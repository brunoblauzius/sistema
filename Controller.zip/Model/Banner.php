<?php 

class Banner extends AppModel{

	
	public $useTable = 'banner';

	public $name = 'Banner';

	public $primaryKey = 'id';


	public $validate = array();


}