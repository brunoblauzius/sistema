<?php

/**
 * componente para meus htmls
 * @version 1.0
 */

trait HtmlHelper {
    
    //meu constructor
    public function HtmlHelper(){}
    
    public final function css( $name ){
        return '';
    }
    
    public final function script( $name ){
        return '';
    }
    
}
