<h3>Recupera Senha</h3>
<hr>
<p>
    Para efetivar sua alteração de senha clique no linque e cadestre a nova senha de usuário
</p>
<a href="<?= $url?>Pages/recuperarSenha/KEY_DO_USUARIO"> Clique aqui para reculera a senha</a>
<?php print_r($url);?>
<br>
<br>
Equipe da jopacs agradece!<br>
<br>
<br>
<small>Obs. não responder este e-mail</small>