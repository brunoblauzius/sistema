<h3>Contato do site</h3>
<hr>

<table style="width:500px;">
    <tbody>
        <tr>
            <td>Nome:</td>
            <td><strong><?php echo $contato['nome'] ?></strong></td>
        </tr>
        <tr>
            <td>Email:</td>
            <td><strong><?php echo $contato['email'] ?></strong></td>
        </tr>
        <tr>
            <td>Assunto:</td>
            <td><strong><?php echo $contato['assunto'] ?></strong></td>
        </tr>
        <tr>
            <td>Mensagem:</td>
            <td><strong><?php echo $contato['mensagem'] ?></strong></td>
        </tr>
    </tbody>
</table>


<br>
Equipe da jopacs agradece!<br>
<br>
<br>
<small>Obs. não responder este e-mail</small>