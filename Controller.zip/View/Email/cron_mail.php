<h3>Vacina Agendada para <?php echo ($data) ?></h3>
<hr>

<table style="width:500px;">
    <tbody>
        <tr>
            <td>Nome:</td>
            <td><strong><?php echo $usuario['nome'] ?></strong></td>
        </tr>
        <tr>
            <td>Local da vacina:</td>
            <td><strong><?php echo $usuario['localVacina'] ?></strong></td>
        </tr>
        <tr>
            <td>Data para sua vacina:</td>
            <td><strong><?php echo ($data) ?></strong></td>
        </tr>
    </tbody>
</table>


<br>
Equipe da jopacs agradece!<br>
<br>
<br>
<small>Obs. não responder este e-mail</small>