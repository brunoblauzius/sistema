<section class="alert alert-danger">
    <h2 class="text-center">
        <?= $mensagem;?>
    </h2>
</section>