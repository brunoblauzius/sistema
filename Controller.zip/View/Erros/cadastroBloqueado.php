<section class="alert alert-warning">
    <h2 class="text-center">
        <?= $mensagem;?>
    </h2>
</section>