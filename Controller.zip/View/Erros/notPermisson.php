<section class="panel">
    <div class="panel panel-body">
        <h2><?= $mensagem?></h2>
        
        <div class="clearfix"></div>
        <div class="col-md-12 text-center">
            <a href="<?= Router::url(array('Carrinhos', 'index'))?>" class="btn btn-primary btn-lg">Continuar Utilizando o Sistema</a>
        </div>
    </div>
</section>