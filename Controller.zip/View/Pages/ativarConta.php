<div class="row">
    <div class="col-md-12">
        <h3 class="pgtitulo"> Conta Ativada Com sucesso!</h3>
    
        <p>
            Sua conta foi ativada com sucesso! favor <a href="<?php echo $this->urlRoot()?>/Pages/login">clique aqui para logar-se</a>
        </p>
    </div>
</div>