<!DOCTYPE html>
<html class="bg-black">
    <head>
        <meta charset="<?= $this->charset;?>">
        <title><?= $title_layout; ?></title>
		<link rel="shortcut icon" href="icone.png">
    </head>
    <body class="bg-black">
        <?= $this->showView(); ?>
    </body>
</html>
