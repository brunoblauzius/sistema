﻿    <link href="<?= $this->urlRoot()?>View/webroot/bs3/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= $this->urlRoot()?>View/webroot/font-awesome/css/font-awesome.css" rel="stylesheet" />
	
	<style>
		table{ font-size: 12px;}
	</style>

    <!-- Custom styles for this template -->

	<!-- show conteudo -->
	<?= $this->showView(); ?>
	<!-- Modal -->